<?php
/**
 * Plugin Name: FSR Raumbelegung
 * Description: Zeigt freie Räume im POT. Daten von TU-Navigator JSON-API. Aktualisierung jeden Montag.
 * Version:     4.0.0
 * Author:      FSR Verkehr – TU Dresden
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'FSR_RB_VERSION',   '4.0.0' );
define( 'FSR_RB_CACHE_KEY', 'fsr_rb_v4' );
define( 'FSR_RB_CRON_HOOK', 'fsr_rb_refresh' );
define( 'FSR_RB_API_BASE',  'https://navigator.tu-dresden.de/m/json_belegplan/' );

// Räume mit Navigator-IDs (aus Program.cs)
const FSR_RB_ROOMS = [
    'POT/  6/H' => '325100.0090',
    'POT/ 13/U' => '325100.0220',
    'POT/ 51/H' => '325300.0010',
    'POT/ 81/H' => '325501.0090',
    'POT/106/U' => '325101.0080',
    'POT/112/H' => '325101.0230',
    'POT/151/H' => '325301.0010',
    'POT/251/H' => '325302.0020',
    'POT/351/U' => '325303.0010',
    'POT/361/H' => '325303.0220',
];

const FSR_RB_DS_TIMES = [
    1 => '07:30–09:00',
    2 => '09:20–10:50',
    3 => '11:10–12:40',
    4 => '13:00–14:30',
    5 => '14:50–16:20',
    6 => '16:40–18:10',
    7 => '18:30–20:00',
    8 => '20:20–21:50',
    9 => '22:10–23:40',
];

const FSR_RB_DAYS_DE = [0=>'Mo',1=>'Di',2=>'Mi',3=>'Do',4=>'Fr'];
const FSR_RB_DAYS_EN = [0=>'Mon',1=>'Tue',2=>'Wed',3=>'Thu',4=>'Fri'];

// ═══════════════════════════════════════════════════════════════════════════════
register_activation_hook( __FILE__, function() {
    if ( ! wp_next_scheduled( FSR_RB_CRON_HOOK ) ) {
        $tz  = new DateTimeZone( 'Europe/Berlin' );
        $now = new DateTimeImmutable( 'now', $tz );
        $dow = (int) $now->format( 'N' );
        $add = ( $dow === 1 ) ? 7 : ( 8 - $dow );
        $ts  = (int) $now->modify( "+{$add} days" )->setTime( 3, 0 )->getTimestamp();
        wp_schedule_event( $ts, 'weekly', FSR_RB_CRON_HOOK );
    }
    fsr_rb_refresh_cache();
} );

register_deactivation_hook( __FILE__, function() {
    $ts = wp_next_scheduled( FSR_RB_CRON_HOOK );
    if ( $ts ) wp_unschedule_event( $ts, FSR_RB_CRON_HOOK );
} );

// ═══════════════════════════════════════════════════════════════════════════════
add_action( FSR_RB_CRON_HOOK, 'fsr_rb_refresh_cache' );

function fsr_rb_refresh_cache(): void {
    $free = [
        'woche1' => fsr_rb_empty_week(),
        'woche2' => fsr_rb_empty_week(),
    ];

    $rooms_ok   = [];
    $rooms_fail = [];

    foreach ( FSR_RB_ROOMS as $room_name => $room_id ) {
        $url  = FSR_RB_API_BASE . $room_id;
        $resp = wp_remote_get( $url, [
            'timeout'     => 20,
            'redirection' => 5,
            'httpversion' => '1.1',
            'user-agent'  => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'decompress'  => true,
            'headers'     => [
                'Accept'          => 'application/json, text/javascript, */*; q=0.01',
                'Accept-Encoding' => 'gzip, deflate',
            ],
        ] );

        if ( is_wp_error( $resp ) ) {
            $rooms_fail[] = $room_name . ' (WP Error: ' . $resp->get_error_message() . ')';
            continue;
        }

        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) {
            $rooms_fail[] = $room_name . ' (HTTP ' . $code . ')';
            continue;
        }

        $body = wp_remote_retrieve_body( $resp );
        if ( empty( $body ) ) {
            $rooms_fail[] = $room_name . ' (Empty body)';
            continue;
        }

        // BOM und Whitespace entfernen
        $body = trim( $body );
        $body = preg_replace( '/^\xEF\xBB\xBF/', '', $body );
        
        // UTF-8 Encoding sicherstellen
        if ( ! mb_check_encoding( $body, 'UTF-8' ) ) {
            $body = mb_convert_encoding( $body, 'UTF-8', 'UTF-8' );
        }
        
        if ( stripos( $body, '"error"' ) !== false ) {
            $rooms_fail[] = $room_name . ' (API error in response)';
            continue;
        }

        $data = json_decode( $body, true );
        if ( ! is_array( $data ) ) {
            $rooms_fail[] = $room_name . ' (Invalid JSON: ' . json_last_error_msg() . ')';
            continue;
        }

        $rooms_ok[] = $room_name;

        // Freie Slots ermitteln
        foreach ( ['woche1', 'woche2'] as $w ) {
            if ( empty( $data[ $w ] ) || ! is_array( $data[ $w ] ) ) {
                // Woche fehlt → Raum komplett frei markieren
                for ( $dow = 0; $dow <= 4; $dow++ ) {
                    for ( $ds = 1; $ds <= 9; $ds++ ) {
                        $free[ $w ][ $dow ][ $ds ][] = $room_name;
                    }
                }
                continue;
            }

            // Belegte Slots sammeln
            $occupied = [];
            foreach ( $data[ $w ] as $day_entry ) {
                if ( ! isset( $day_entry['tag'] ) ) continue;
                $dow = (int) $day_entry['tag'];
                if ( isset( $day_entry['stunden'] ) && is_array( $day_entry['stunden'] ) ) {
                    foreach ( $day_entry['stunden'] as $stunde ) {
                        if ( isset( $stunde['ds'] ) ) {
                            $occupied[ $dow ][ (int) $stunde['ds'] ] = true;
                        }
                    }
                }
            }

            // Freie Slots = alle Slots OHNE Belegung
            for ( $dow = 0; $dow <= 4; $dow++ ) {
                for ( $ds = 1; $ds <= 9; $ds++ ) {
                    if ( empty( $occupied[ $dow ][ $ds ] ) ) {
                        $free[ $w ][ $dow ][ $ds ][] = $room_name;
                    }
                }
            }
        }
    }

    $result = [
        'data'       => $free,
        'fetched'    => time(),
        'rooms_ok'   => $rooms_ok,
        'rooms_fail' => $rooms_fail,
    ];

    set_transient( FSR_RB_CACHE_KEY, $result, 8 * DAY_IN_SECONDS );
    update_option( 'fsr_raumbelegung_last_updated', time() );
}

function fsr_rb_empty_week(): array {
    $w = [];
    for ( $dow = 0; $dow <= 4; $dow++ ) {
        for ( $ds = 1; $ds <= 9; $ds++ ) {
            $w[ $dow ][ $ds ] = [];
        }
    }
    return $w;
}

// ═══════════════════════════════════════════════════════════════════════════════
add_shortcode( 'fsr_raumbelegung_de', function( $atts ) {
    return fsr_rb_render( shortcode_atts(['week'=>'current'],$atts)['week']==='next'?1:0, 'de' );
} );
add_shortcode( 'fsr_raumbelegung_en', function( $atts ) {
    return fsr_rb_render( shortcode_atts(['week'=>'current'],$atts)['week']==='next'?1:0, 'en' );
} );

// ═══════════════════════════════════════════════════════════════════════════════
function fsr_rb_render( int $offset, string $lang ): string {
    $is_de = ( $lang === 'de' );
    $cache = get_transient( FSR_RB_CACHE_KEY );

    static $css_done = false;
    $css = '';
    if ( ! $css_done ) { $css = fsr_rb_css(); $css_done = true; }

    if ( ! is_array( $cache ) || empty( $cache['data'] ) ) {
        $msg = $is_de ? 'Keine Daten verfügbar – bitte Plugin-Einstellungen prüfen.'
                      : 'No data available – please check plugin settings.';
        return $css . '<p style="color:#c00;font-style:italic">' . esc_html( $msg ) . '</p>';
    }

    $tz     = new DateTimeZone( 'Europe/Berlin' );
    $now    = new DateTimeImmutable( 'now', $tz );
    $target = $now->modify( ( $offset * 7 ) . ' days' );
    $iso_kw = (int) $target->format( 'W' );
    $week_key = ( $iso_kw % 2 === 1 ) ? 'woche1' : 'woche2';
    $monday = $target->modify( 'Monday this week' );
    $friday = $target->modify( 'Friday this week' );
    $today  = $now->format( 'Y-m-d' );

    $week_data = $cache['data'][ $week_key ] ?? [];
    $fetched   = $cache['fetched'] ?? 0;

    $days = $is_de ? FSR_RB_DAYS_DE : FSR_RB_DAYS_EN;
    $fmt  = $is_de ? 'd.m.' : 'm/d';

    $week_type = ( $iso_kw % 2 === 1 ) ? ($is_de ? 'Ungerade' : 'Odd') : ($is_de ? 'Gerade' : 'Even');
    $title = $is_de
        ? ( $offset === 0 ? 'Freie Räume – Aktuelle Woche' : 'Freie Räume – Nächste Woche' )
        : ( $offset === 0 ? 'Free Rooms – Current Week'    : 'Free Rooms – Next Week' );

    ob_start();
    echo $css; // phpcs:ignore
    ?>
    <div class="fsr-rb">
        <p class="fsr-rb-meta">
            <strong><?php echo esc_html( $title ); ?></strong>
            &nbsp;|&nbsp; KW <?php echo esc_html( $iso_kw ); ?> (<?php echo esc_html( $week_type ); ?>)
            &nbsp;|&nbsp; <?php echo esc_html( $monday->format($fmt) . '–' . $friday->format($fmt.'Y') ); ?>
            <?php if ( $fetched ) :
                $lu = (new DateTimeImmutable('@'.$fetched))->setTimezone($tz);
                echo ' &nbsp;|&nbsp; ' . ($is_de?'Stand':'Updated') . ': ' . esc_html($lu->format('d.m.'));
            endif; ?>
        </p>

        <table class="fsr-rb-table">
            <thead>
                <tr>
                    <th class="fsr-rb-th-ds">DS</th>
                    <?php for ( $dow = 0; $dow <= 4; $dow++ ) :
                        $date = $monday->modify( "+{$dow} days" );
                        $is_today = $date->format('Y-m-d') === $today;
                    ?>
                    <th<?php echo $is_today ? ' class="fsr-rb-today"' : ''; ?>>
                        <?php echo esc_html( $days[$dow] ); ?><br>
                        <span class="fsr-rb-date"><?php echo esc_html( $date->format($fmt) ); ?></span>
                    </th>
                    <?php endfor; ?>
                </tr>
            </thead>
            <tbody>
                <?php for ( $ds = 1; $ds <= 9; $ds++ ) : ?>
                <tr>
                    <td class="fsr-rb-ds">
                        <?php echo esc_html( $ds ); ?>.<br>
                        <span class="fsr-rb-time"><?php echo esc_html( FSR_RB_DS_TIMES[$ds] ); ?></span>
                    </td>
                    <?php for ( $dow = 0; $dow <= 4; $dow++ ) :
                        $date    = $monday->modify( "+{$dow} days" );
                        $is_today = $date->format('Y-m-d') === $today;
                        $rooms   = $week_data[$dow][$ds] ?? [];
                    ?>
                    <td<?php echo $is_today ? ' class="fsr-rb-today"' : ''; ?>>
                        <?php if ( empty( $rooms ) ) : ?>
                            <span class="fsr-rb-occ">&ndash;</span>
                        <?php else : ?>
                            <?php foreach ( $rooms as $r ) : ?>
                                <span class="fsr-rb-room"><?php echo esc_html( trim($r) ); ?></span>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </td>
                    <?php endfor; ?>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>

        <p class="fsr-rb-footer">
            <?php
            $lbl = $is_de ? 'Geprüfte Räume' : 'Checked rooms';
            echo esc_html( $lbl . ': ' . implode( ', ', array_map('trim', $cache['rooms_ok'] ?? []) ) );
            if ( ! empty( $cache['rooms_fail'] ) ) {
                $fail_lbl = $is_de ? 'Fehler' : 'Error';
                echo ' | <span style="color:#c00">' . esc_html( $fail_lbl . ': ' . implode( ', ', $cache['rooms_fail'] ) ) . '</span>';
            }
            ?>
            &nbsp;|&nbsp; <a href="https://navigator.tu-dresden.de/" target="_blank" rel="noopener">TU Navigator</a>
        </p>
    </div>
    <?php
    return ob_get_clean();
}

function fsr_rb_css(): string { return <<<'CSS'
<style>
.fsr-rb { font-family: inherit; font-size: 0.9rem; margin: 1rem 0; }
.fsr-rb-meta { margin-bottom: 0.5rem; font-size: 0.85rem; color: #444; }
.fsr-rb-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
.fsr-rb-table th, .fsr-rb-table td { border: 1px solid #ccc; padding: 0.4rem 0.5rem; text-align: left; vertical-align: top; }
.fsr-rb-table thead th { background: #003062; color: #fff; font-weight: 600; white-space: nowrap; }
.fsr-rb-table thead th.fsr-rb-today { background: #004990; box-shadow: inset 0 0 0 2px #e2001a; }
.fsr-rb-table tbody tr:nth-child(even) td { background: #f7f7f7; }
.fsr-rb-table tbody td.fsr-rb-today { background: #fffbe6; }
.fsr-rb-th-ds { width: 80px; }
.fsr-rb-ds { white-space: nowrap; color: #444; font-size: 0.85rem; font-weight: 600; }
.fsr-rb-time { font-weight: normal; font-size: 0.75rem; opacity: 0.8; }
.fsr-rb-date { font-weight: normal; font-size: 0.75rem; opacity: 0.85; }
.fsr-rb-room { display: inline-block; font-size: 0.8rem; font-weight: 600; color: #003062; margin: 1px 3px 1px 0; }
.fsr-rb-occ { color: #bbb; }
.fsr-rb-footer { font-size: 0.75rem; color: #666; margin-top: 0.4rem; }
@media (max-width: 600px) {
    .fsr-rb-table th, .fsr-rb-table td { padding: 0.25rem 0.3rem; font-size: 0.8rem; }
    .fsr-rb-ds { font-size: 0.75rem; }
    .fsr-rb-time { font-size: 0.7rem; }
}
</style>
CSS; }

// ═══════════════════════════════════════════════════════════════════════════════
add_action( 'admin_menu', function() {
    add_options_page( 'FSR Raumbelegung', 'FSR Raumbelegung', 'manage_options', 'fsr-raumbelegung', 'fsr_rb_admin_page' );
} );

function fsr_rb_admin_page(): void {
    if ( ! current_user_can( 'manage_options' ) ) return;

    if ( isset( $_POST['fsr_rb_refresh'] ) && check_admin_referer( 'fsr_rb_nonce' ) ) {
        fsr_rb_refresh_cache();
        echo '<div class="notice notice-success is-dismissible"><p>Cache aktualisiert.</p></div>';
    }

    $cache = get_transient( FSR_RB_CACHE_KEY );
    $tz    = new DateTimeZone( 'Europe/Berlin' );
    $now   = new DateTimeImmutable( 'now', $tz );
    $kw    = (int) $now->format('W');
    $next  = wp_next_scheduled( FSR_RB_CRON_HOOK );
    $next_str = $next ? (new DateTimeImmutable('@'.$next))->setTimezone($tz)->format('d.m.Y H:i') : '–';
    ?>
    <div class="wrap">
    <h1>FSR Raumbelegung – Einstellungen</h1>

    <h2>Status</h2>
    <table class="form-table">
        <tr><th>Aktuelle KW</th>
            <td><strong>KW <?php echo esc_html($kw); ?></strong>
                = <?php echo ($kw%2===1)?'Ungerade (woche1)':'Gerade (woche2)'; ?></td></tr>
        <tr><th>Cache</th>
            <td><?php if ( is_array($cache) ):
                $lu = (new DateTimeImmutable('@'.$cache['fetched']))->setTimezone($tz);
                echo '<span style="color:green">✔ Vorhanden</span> – ' . esc_html($lu->format('d.m.Y H:i')) . '<br>';
                echo 'OK: ' . esc_html(implode(', ', $cache['rooms_ok']??[]));
                if (!empty($cache['rooms_fail'])):
                    echo '<br><span style="color:red">Fehler: ' . esc_html(implode(', ', $cache['rooms_fail'])) . '</span>';
                endif;
            else: echo '<span style="color:red">✘ Kein Cache</span>';
            endif; ?></td></tr>
        <tr><th>Nächste Aktualisierung</th>
            <td><?php echo esc_html($next_str); ?> (Montag 03:00 Uhr)</td></tr>
    </table>

    <form method="post">
        <?php wp_nonce_field('fsr_rb_nonce'); ?>
        <input type="hidden" name="fsr_rb_refresh" value="1">
        <?php submit_button('Jetzt aktualisieren', 'secondary'); ?>
    </form>

    <hr>
    <h2>Shortcodes</h2>
    <table class="widefat striped" style="max-width:600px">
        <thead><tr><th>Shortcode</th><th>Ausgabe</th></tr></thead>
        <tbody>
            <tr><td><code>[fsr_raumbelegung_de]</code></td><td>Aktuelle Woche DE</td></tr>
            <tr><td><code>[fsr_raumbelegung_de week="next"]</code></td><td>Nächste Woche DE</td></tr>
            <tr><td><code>[fsr_raumbelegung_en]</code></td><td>Current week EN</td></tr>
            <tr><td><code>[fsr_raumbelegung_en week="next"]</code></td><td>Next week EN</td></tr>
        </tbody>
    </table>

    <hr>
    <h2>API-Endpunkte (JSON)</h2>
    <table class="widefat striped" style="max-width:700px">
        <thead><tr><th>Raum</th><th>URL</th></tr></thead>
        <tbody>
        <?php foreach (FSR_RB_ROOMS as $name => $id): ?>
            <tr>
                <td><?php echo esc_html($name); ?></td>
                <td><a href="<?php echo esc_url(FSR_RB_API_BASE.$id); ?>" target="_blank">
                    <?php echo esc_html(FSR_RB_API_BASE.$id); ?>
                </a></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php
}
