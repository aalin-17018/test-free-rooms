# FSR Raumbelegung v2 – WordPress Plugin

Zeigt **freie Räume im Potthoff-Bau (POT)** für die aktuelle & nächste Woche (DE/EN) auf fsr-verkehr.de.

## Datenquelle

TU Dresden Campus Navigator API:
```
https://navigator.tu-dresden.de/m/json_belegplan/{RAUM_ID}
```

Die API liefert Belegungspläne pro Raum mit `woche1`/`woche2` (TU A/B-Wochen-System)
und DS-Nummern (1–9) nach Dresdner Stundenraster.

### Integrierte Räume (aus Program.cs übernommen)
| Raum       | Navigator-ID  |
|------------|---------------|
| POT/  6/H  | 325100.0090   |
| POT/ 13/U  | 325100.0220   |
| POT/ 51/H  | 325300.0010   |
| POT/ 81/H  | 325501.0090   |
| POT/106/U  | 325101.0080   |
| POT/112/H  | 325101.0230   |
| POT/151/H  | 325301.0010   |
| POT/251/H  | 325302.0020   |
| POT/351/U  | 325303.0010   |
| POT/361/H  | 325303.0220   |

## Installation

1. `fsr-raumbelegung/`-Ordner nach `wp-content/plugins/` kopieren
2. In WordPress → Plugins aktivieren
3. Unter **Einstellungen → FSR Raumbelegung** prüfen/einrichten
4. Shortcodes auf gewünschten Seiten einfügen

## Shortcodes

| Shortcode | Ausgabe |
|---|---|
| `[fsr_raumbelegung_de]` | Aktuelle Woche – Deutsch |
| `[fsr_raumbelegung_de week="next"]` | Nächste Woche – Deutsch |
| `[fsr_raumbelegung_en]` | Aktuelle Woche – Englisch |
| `[fsr_raumbelegung_en week="next"]` | Nächste Woche – Englisch |

## Dresdner Stundenraster (DS)

| DS | Beginn | Ende  |
|----|--------|-------|
| 1. | 07:30  | 09:00 |
| 2. | 09:20  | 10:50 |
| 3. | 11:10  | 12:40 |
| 4. | 13:00  | 14:30 |
| 5. | 14:50  | 16:20 |
| 6. | 16:40  | 18:10 |
| 7. | 18:30  | 20:00 |
| 8. | 20:15  | 21:45 |
| 9. | 21:45  | 23:15 |

## Wochentyp A/B

Die TU verwendet A/B-Wochen (woche1/woche2). Das Plugin berechnet den Typ
ausschließlich aus der ISO-Wochennummer: **KW ungerade = Woche A**.
Falls die Anzeige invertiert erscheint → Einstellung "Wochentyp-Offset" auf 1 setzen.

## Automatische Aktualisierung

Jeden **Montag 03:00 Uhr** (Europe/Berlin) via WP-Cron.
Für zuverlässigeres Verhalten empfohlen:
```
0 3 * * 1 curl -s https://fsr-verkehr.de/wp-cron.php?doing_wp_cron >/dev/null
```
